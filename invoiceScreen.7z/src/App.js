import './App.css';
import InvoiceScreen from './Veiws/InvoiceScreen';

function App() {
  return (
    <div className="App">
      <InvoiceScreen />
    </div>
  );
}

export default App;
