import React from 'react';
import PropTypes from 'prop-types';
import { useSelector, useDispatch } from 'react-redux';
import { makeStyles } from '@material-ui/core/styles';
import InfiniteScroll from 'react-infinite-scroll-component';
import CircularProgress from '@material-ui/core/CircularProgress';
import dateHelper from '../Helpers.js/dateHelper';
import amountFormatter from '../Helpers.js/amountHelper';
import {
  isAllCheckedAction,
  isEachChecked,
} from '../Utils/actions/invoiceSagaActions';

import {
  Paper,
  Table,
  TableHead,
  TableBody,
  TableCell,
  TableRow,
} from '@material-ui/core';
import Checkbox from '@material-ui/core/Checkbox';

const propTypes = {
  data: PropTypes.object,
  startApiCall: PropTypes.func,
};

function InvoiceTable(props) {
  const useStyle = makeStyles(() => ({
    card: {
      backgroundColor: '#252C48',
    },
    root: {
      width: '100%',
      minHeight: '90%',
      height: '60vh',
      overflowY: 'scroll',
      backgroundColor: '#273D49CC',
      '&::-webkit-scrollbar': {
        width: '0.4em',
      },
      '&::-webkit-scrollbar-track': {
        '-webkit-box-shadow': 'inset 0 0 6px rgba(0,0,0,0.00)',
      },
      '&::-webkit-scrollbar-thumb': {
        backgroundColor: '#61707B',
        outline: '1px solid slategrey',
      },
    },
    oddRow: {
      backgroundColor: '#23313a',
    },
    table: {
      minWidth: '90%',
      backgroundColor: '#273D49CC',
      height: '60vh',
    },
    tableHeader: {
      padding: '5px 5px 5px 15px',
      color: '#fff',
    },
    textColor: {
      color: '#fff !important',
      padding: 0,
      //backgroundColor: 'red',
    },
    checked: {
      color: '#14AFF1',
    },
    checkBox: {
      color: '#97A1A9',
    },
    headerColor: {
      color: '#97A1A9',
      padding: '5px',
    },
    input: {
      width: '100%',
    },
    infiniteScroll: {
      overflow: 'hidden !important',
    },
    defaultRowColor: {
      color: '#fff !important',
      padding: 0,
      //backgroundColor: 'green',
    },
    defaultRowColorOdd: {
      color: '#fff !important',
      padding: 0,
      backgroundColor: '#3d515f',
    },
  }));
  constructor(){
   
    
    state={
        
    }
  }
  const classes = useStyle();
  const { data, startApiCall } = props;
  const initialCheckedState = [];
  for (let i = 0; i < data.length; i++) {
    initialCheckedState.push(false);
  }

  const dispatch = useDispatch();
  const handleAllCheck = () => {
    let prevData = [...data]; //newInstance
    prevData = prevData.map((inv, index) => {
      const invoice = { ...inv };
      invoice.isChecked = !isAll; //toggle for all based on previous
      return invoice;
    });
    dispatch(isAllCheckedAction(!isAll));
    dispatch(isEachChecked(prevData));
  };

  const handleEachChecked = (id) => {
    let checkAllChecked = true;
    let prevData = [...data]; //newInstance
    prevData = prevData.map((inv, index) => {
      const invoice = { ...inv };

      if (index === id) {
        invoice.isChecked = !inv.isChecked;
      }
      if (!invoice.isChecked) {  //if any one of isChecked false set isAllCheckedFalse
        checkAllChecked = false;
      }
      return invoice;
    });
    dispatch(isAllCheckedAction(checkAllChecked));
    dispatch(isEachChecked(prevData));
  };
  const isAll = useSelector((state) => state.invoiceTableReducer.isAllChecked);

  return (
    <div>
      <Paper id="scrollable" className={classes.root}>
        <InfiniteScroll
          dataLength={data?.length}
          hasMore={true}
          next={() => {
            console.log('infinte scroll');
            startApiCall();
          }}
          className={classes.infiniteScroll}
          scrollableTarget="scrollable"
          loader={<CircularProgress />}
        >
          <Table className={classes.table}>
            <TableHead>
              <TableRow>
                <TableCell>
                  <Checkbox
                    checked={isAll ? true : false}
                    onClick={handleAllCheck}
                    className={classes.checkBox}
                  />
                </TableCell>
                <TableCell
                  autoid="customer-name"
                  className={classes.headerColor}
                >
                  Customer Name
                </TableCell>
                <TableCell
                  autoid="customer-number"
                  className={classes.headerColor}
                >
                  Customer Number
                </TableCell>
                <TableCell
                  autoid="customer-name"
                  className={classes.headerColor}
                >
                  Invoice Number
                </TableCell>{' '}
                <TableCell
                  autoid="customer-name"
                  className={classes.headerColor}
                >
                  Invoice Amount
                </TableCell>{' '}
                <TableCell
                  autoid="customer-name"
                  className={classes.headerColor}
                >
                  Due Date
                </TableCell>{' '}
                <TableCell
                  autoid="customer-name"
                  className={classes.headerColor}
                >
                  Predicted Payment Date
                </TableCell>{' '}
                <TableCell
                  autoid="customer-name"
                  className={classes.headerColor}
                >
                  Predicted Aging Bucket
                </TableCell>{' '}
                <TableCell
                  autoid="customer-name"
                  className={classes.headerColor}
                >
                  Notes
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {data.map((d, i) => {
                return (
                  <TableRow
                    key={i}
                    className={
                      i % 2 === 0
                        ? classes.defaultRowColor
                        : classes.defaultRowColorOdd
                    }
                  >
                    <TableCell>
                      <Checkbox
                        checked={d.isChecked ? true : false}
                        onClick={() => {
                          handleEachChecked(i);
                        }}
                      />
                    </TableCell>
                    <TableCell className={classes.textColor}>
                      {d.customerName ? d.customerName : '-'}
                    </TableCell>
                    <TableCell className={classes.textColor}>
                      {d.customerNumber ? d.customerNumber : '-'}
                    </TableCell>
                    <TableCell className={classes.textColor}>
                      {d.invoiceNumber ? d.invoiceNumber : '-'}
                    </TableCell>
                    <TableCell className={classes.textColor}>
                      {d.invoiceAmount ? amountFormatter(d.invoiceAmount) : '-'}
                    </TableCell>{' '}
                    <TableCell className={classes.textColor}>
                      {d.dueDate ? dateHelper(d.dueDate) : '-'}
                    </TableCell>{' '}
                    <TableCell className={classes.textColor}>
                      {d.predictedPaymentDate ? d.predictedAgingBucket : '-'}
                    </TableCell>
                    <TableCell className={classes.textColor}>
                      {d.predictedAgingBucket ? d.predictedAgingBucket : '-'}
                    </TableCell>
                    <TableCell className={classes.textColor}>
                      {d.notes}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </InfiniteScroll>
      </Paper>
    </div>
  );
}

InvoiceTable.propTypes = propTypes;

export default InvoiceTable;
