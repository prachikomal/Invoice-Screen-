import React from 'react';

import AddIcon from '@material-ui/icons/Add';
import { makeStyles } from '@material-ui/core/styles';

import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Typography from '@material-ui/core/Typography';

const useStyle = makeStyles(() => ({
  root: {
    margin: 0,
    padding: '16px',
  },
  closeButton: {
    position: 'absolute',
    right: '8px',
    top: '8px',
    color: 'grey',
  },
  buttonText: {
    fontSize: '12px',
    color: '#ffffff',
    textTransform: 'none',
  },
  addIcon: {
    color: '#ffffff',
    height: '15px',
    width: '15px',
  },
  manipulationButtons: {
    height: '25px',
    width: '40px',
    border: '1px solid #14AFF1',
  },
  dialogueActions: {
    root: {
      margin: 0,
      padding: '8px',
    },
    display: 'flex',
    background: '#283A46 0% 0% no-repeat padding-box',
  },
  cancelButton: {
    flexGrow: 1,
  },
  okButton: {
    flexDirection: 'row-reverse',
  },
  dialogueContent: {
    background: '#283A46 0% 0% no-repeat padding-box',
  },
  titleArea: {
    background: '#283A46 0% 0% no-repeat padding-box',
    color: '#ffffff',
  },
  addedInvoicesDiv: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  addedInvoicesText: {
    color: '#ffffff',
    paddingTop: '50px',
    paddingBottom: '50px',
    paddingLeft: '200px',
    paddingRight: '200px',
  },
  cancelText: {
    color: '#14AFF1',
    textTransform: 'none',
  },
  okButtonStyle: {
    backgroundColor: '#14AFF1',
  },
}));

const DialogTitle = (props) => {
  const { children, onClose, ...other } = props;
  const classes = useStyle();
  return (
    <MuiDialogTitle disableTypography className={classes.root} {...other}>
      <Typography variant="h6">{children}</Typography>
      {onClose ? (
        <IconButton
          aria-label="close"
          className={classes.closeButton}
          onClick={onClose}
        >
          <CloseIcon />
        </IconButton>
      ) : null}
    </MuiDialogTitle>
  );
};

export default function CustomizedDialogs() {
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  const classes = useStyle();

  return (
    <>
      <Button className={classes.manipulationButtons} onClick={handleClickOpen}>
        {' '}
        <AddIcon className={classes.addIcon} />
        <Typography className={classes.buttonText}> Add</Typography>
      </Button>{' '}
      <Dialog
        onClose={handleClose}
        aria-labelledby="customized-dialog-title"
        open={open}
      >
        <DialogTitle
          id="customized-dialog-title"
          className={classes.titleArea}
          onClose={handleClose}
        >
          Add Invoice
        </DialogTitle>
        <MuiDialogContent className={classes.dialogueContent} dividers>
          <div className={classes.addedInvoicesDiv}>
            <Typography className={classes.addedInvoicesText}>
              Invoices Added
            </Typography>
          </div>
        </MuiDialogContent>
        <MuiDialogActions className={classes.dialogueActions}>
          <div className={classes.cancelButton}>
            <Button autoFocus onClick={handleClose}>
              <Typography className={classes.cancelText}>Cancel</Typography>
            </Button>
          </div>
          <div className={classes.okButton}>
            <Button
              autoFocus
              onClick={handleClose}
              className={classes.okButtonStyle}
            >
              OK
            </Button>
          </div>
        </MuiDialogActions>
      </Dialog>
    </>
  );
}
