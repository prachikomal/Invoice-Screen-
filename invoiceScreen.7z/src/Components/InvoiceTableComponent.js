import React from 'react';
import PropTypes from 'prop-types';
import Header from '../Components/Header';
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';
import { makeStyles } from '@material-ui/core/styles';
import { Card, CardContent } from '@material-ui/core';
import InvoiceTableHeader from './InvoiceTableHeader';
import InvoiceTableToolbar from './InvoiceTableToolbar';
import InvoiceTable from './InvoiceTable';

const theme = createMuiTheme({
  overrides: {
    MuiTableCell: {
      root: {
        paddingTop: 0,
        paddingBottom: 0,
        '&:last-child': {
          paddingRight: 0,
        },
      },
    },
  },
});

const propTypes = {
  data: PropTypes.object,
  startApiCall: PropTypes.func,
};

function InvoiceTableComponent(props) {
  const useStyle = makeStyles(() => ({
    card: {
      background:
        'transparent radial-gradient(closest-side at 50% 50%, #58687E 0%, #39495E 100%) 0% 0% no-repeat padding-box',
      position: 'absolute',
      top: '10%',
      height: '90%',
      width: '100%',
    },
    cardContent: {
      backgroundColor: '#273D49CC',

      height: '80%',

      padding: '30px',
    },
  }));

  const classes = useStyle();
  return (
    <div>
      <Header />
      <Card className={classes.card}>
        <InvoiceTableHeader />
        <CardContent className={classes.cardContent}>
          <InvoiceTableToolbar />
          <MuiThemeProvider theme={theme}>
            <InvoiceTable data={props.data} startApiCall={props.startApiCall} />
          </MuiThemeProvider>
        </CardContent>
      </Card>
    </div>
  );
}
InvoiceTableComponent.propTypes = propTypes;
export default InvoiceTableComponent;
