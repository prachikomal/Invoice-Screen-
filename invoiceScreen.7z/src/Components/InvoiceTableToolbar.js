import { makeStyles } from '@material-ui/core/styles';
import { Button, Typography, InputBase } from '@material-ui/core';
import EditIcon from '@material-ui/icons/Edit';
import RemoveIcon from '@material-ui/icons/Remove';
import SearchIcon from '@material-ui/icons/Search';
import AddInvoicesDialog from '../Components/AddInvoicesDialog';

function App() {
  const useStyle = makeStyles(() => ({
    toolBar: {
      height: '60px',
      width: '100%',
      display: 'flex',
    },
    toolBarLeft: {
      display: 'flex',
      flexGrow: 1,
    },
    buttonText: {
      fontSize: '12px',
      color: '#ffffff',
      textTransform: 'none',
    },
    addIcon: {
      color: '#ffffff',
      height: '15px',
      width: '15px',
    },
    manipulationButtons: {
      height: '25px',
      width: '40px',
      border: '1px solid #14AFF1',
    },
    predictButton: {
      height: '25px',
      width: '40px',
      backgroundColor: '#878787',
    },
    searchBar: {
      height: '25px',
      width: '200px',
      marginLeft: '30px',
      border: '1px solid #356680',
      borderRadius: '5px',
    },
    searchIcon: {
      color: 'white',
      height: '15px',
      width: '15px',
      marginLeft: '-15px',
      marginTop: '10px',
    },
    searchInputRoot: {},
    searchInputInput: {
      fontSize: '14px',
      marginLeft: '5px',
      color: '#ffffff',
      marginRight: '15px',
    },
    correspondenceButton: {
      height: '25px',
      width: '200px',
      marginLeft: '30px',
      border: '1px solid #356680',
    },
    toolBarRight: {
      flexDirection: 'row-reverse',
    },
    inputRoot: {
      color: 'inherit',
      width: '100%',
    },
    inputInput: {
      paddingTop: '8px',
      paddingRight: '8px',
      paddingLeft: '40px',
      width: '100%',
    },
  }));
  const classes = useStyle();

  return (
    <div className={classes.toolBar}>
      <div className={classes.toolBarLeft}>
        <Button className={classes.predictButton} variant="contained">
          {' '}
          <Typography className={classes.buttonText}> Predict</Typography>
        </Button>
        <Button className={classes.correspondenceButton}>
          {' '}
          <Typography className={classes.buttonText}>
            {' '}
            View Correspondence
          </Typography>
        </Button>{' '}
      </div>
      <div className={classes.toolBarRight}>
        <AddInvoicesDialog />
        <Button className={classes.manipulationButtons}>
          {' '}
          <EditIcon className={classes.addIcon} />
          <Typography className={classes.buttonText}> Edit</Typography>
        </Button>{' '}
        <Button className={classes.manipulationButtons}>
          {' '}
          <RemoveIcon className={classes.addIcon} />
          <Typography className={classes.buttonText}> Delete</Typography>
        </Button>
        <InputBase
          placeholder="Search Invoices"
          className={classes.searchBar}
          classes={{
            root: classes.SearchInputRoot,
            input: classes.searchInputInput,
          }}
        />
        <SearchIcon className={classes.searchIcon} />
      </div>
    </div>
  );
}

export default App;
