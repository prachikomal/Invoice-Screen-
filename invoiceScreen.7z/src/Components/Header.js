import React from 'react';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Companysvg from '../Assets/companyLogo.svg';
import Highradiussvg from '../Assets/highradius_logo.svg';

function Header(props) {
  const useStyle = makeStyles(() => ({
    title: { fontSize: '1.5rem', margin: '0.5rem' },
    appBar: {
      backgroundColor: '#39495E',
      height: '10%',
    },
    hrcLogo: {
      marginLeft: '100px',
    },
  }));
  const classes = useStyle();
  return (
    <div>
      <AppBar position="static" className={classes.appBar}>
        <Toolbar>
          <img
            src={Companysvg}
            style={{ height: '40px', width: '40px ' }}
            alt="null"
          />
          <Typography variant="h6">
            <h1 className={classes.title}>ABC PRODUCTS</h1>
          </Typography>
          <div className={classes.hrcLogo}>
            <img
              src={Highradiussvg}
              style={{ height: '40px', width: '300px ' }}
              alt="null"
            />
          </div>
        </Toolbar>
      </AppBar>
    </div>
  );
}
export default Header;
