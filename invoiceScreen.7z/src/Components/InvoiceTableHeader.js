import { CardActions, Typography } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';

function App() {
  const useStyle = makeStyles(() => ({
    headerText: {
      color: '#ffffff',
      textTransform: 'none',
      marginLeft: '20px',
    },
  }));
  const classes = useStyle();
  return (
    <CardActions>
      <Typography className={classes.headerText}>Invoice List</Typography>
    </CardActions>
  );
}

export default App;
