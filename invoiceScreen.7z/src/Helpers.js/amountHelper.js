export default function amountFormatter(data) {
  if (data === 0) return '0K';
  if (data > 0 && data < 100) {
    return `${Math.ceil(data)}`;
  }

  if (data >= 100 && data < 1000000) {
    const format = `${Math.round((data / 1000) * 100) / 100}K`;
    if (format === '1000K') {
      return '1M';
    }
    return format;
  }
  if (data > 999999 && data < 1000000000) {
    const formattedAmount = Math.round((data / 1000000) * 100) / 100;
    if (formattedAmount === 1000) return '1B';
    return `${formattedAmount}M`;
  }

  if (data > 999999999) {
    return `${Math.round((data / 1000000000) * 100) / 100}B`;
  }
  return '0K';
}
