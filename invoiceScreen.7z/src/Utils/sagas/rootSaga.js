import { all, fork } from 'redux-saga/effects';

import * as invoiceSagas from './invoiceTableSaga';

export default function* rootSaga() {
  yield all([...Object.values(invoiceSagas)].map(fork));
}
