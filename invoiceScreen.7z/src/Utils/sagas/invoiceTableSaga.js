import { put, takeLatest, call, select, delay } from 'redux-saga/effects';
import {
  invoiceFetchInitated,
  invoiceFetchFailure,
  invoiceFetchSuccess,
  incrementPageNumber,
} from '../actions/invoiceSagaActions';
import axios from 'axios';

function* makeApiCall(pageNumber, pageSize) {
  console.log('check->pageNumber', pageNumber);
  console.log('check -> in api func');
  const response = yield call(
    axios.post,
    `http://localhost:4000/cms/tovo/v1/getInvoices.do?pageNumber=${pageNumber}&pageSize=${pageSize}`
  );

  return response;
}

export function* workerForFetchingInvoices() {
  yield put(invoiceFetchInitated());
  console.log('check -> in Worker');
  try {
    yield delay(5000);
    console.log('check ->in try');
    const pageSize = yield select(
      (state) => state.invoiceTableReducer.pageSize
    );
    const pageNumber = yield select(
      //get PageSize and PageNumber from reducer
      (state) => state.invoiceTableReducer.pageNumber
    );
    const isAllChecked = yield select(
      (state) => state.invoiceTableReducer.isAllChecked
    );
    const res = yield call(makeApiCall, pageNumber, pageSize);
    console.log('check api', res);
    if (res?.data) {
      yield put(incrementPageNumber());

      const data = res.data?.map((inv, index) => {
        inv.isChecked = isAllChecked ? true : false; //initialization
        return inv;
      });

      yield put(invoiceFetchSuccess(data));
    }
  } catch (error) {
    console.log('check error');
    yield put(invoiceFetchFailure());
  }
}

export function* watchForHandleDetailFetch() {
  console.log('check -> in watcher');
  yield takeLatest('START_INVOICE_FETCHING', workerForFetchingInvoices);
}
