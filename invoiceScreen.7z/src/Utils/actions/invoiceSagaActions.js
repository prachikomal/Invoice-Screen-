import {
  INVOICE_FETCH_FAILED,
  INVOICE_FETCH_INITIATED,
  INVOICE_FETCH_SUCCESS,
  START_INVOICE_FETCHING,
  INCREMENT_PAGE_NUMBER,
  CHANGE_ALL_CHECKED,
  CHANGE_EACH_CHECKED,
} from '../actionTypes/actionTypes.js';

export const startInvoiceFetching = () => {
  return {
    type: START_INVOICE_FETCHING,
  };
};

export const isAllCheckedAction = (data) => {
  return {
    type: CHANGE_ALL_CHECKED,
    data,
  };
};

export const isEachChecked = (data) => {
  return {
    type: CHANGE_EACH_CHECKED,
    data,
  };
};
export const invoiceFetchInitated = () => {
  return {
    type: INVOICE_FETCH_INITIATED,
  };
};

export const invoiceFetchSuccess = (payload) => {
  return {
    type: INVOICE_FETCH_SUCCESS,
    payload,
  };
};

export const invoiceFetchFailure = () => {
  return {
    type: INVOICE_FETCH_FAILED,
  };
};

export const incrementPageNumber = () => {
  return {
    type: INCREMENT_PAGE_NUMBER,
  };
};
