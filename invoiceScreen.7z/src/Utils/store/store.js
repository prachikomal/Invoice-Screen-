import { createStore, applyMiddleware, compose, combineReducers } from 'redux';
import createSagaMiddleware from 'redux-saga';
import invoiceTableReducer from '../reducers/invoiceTableReducer';
import rootSaga from '../sagas/rootSaga';

const rootReducer = combineReducers({ invoiceTableReducer });

const sagaMiddleware = createSagaMiddleware();

const middleWares = [sagaMiddleware];

const store = createStore(
  rootReducer,
  window.__REDUX_DEVTOOLS_EXTENSION__
    ? compose(
        applyMiddleware(...middleWares),
        window.__REDUX_DEVTOOLS_EXTENSION__()
      )
    : applyMiddleware(...middleWares)
);
sagaMiddleware.run(rootSaga);
export default store;
