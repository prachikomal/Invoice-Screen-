/**
 * @summary Get the rem for 1920x940
 * @param {Integer} px input px value
 */
export function pxToRem(px) {
  return `${px / 18.018}rem`;
}

export const pxToRem22_5 = (px) => {
  return `${px / 22.5}rem`;
};
// MUI Spacing
export const spacing = (value) => `${pxToRem(value)}`;

/**
 * @param px input px as per 1920 * 940 resolution
   @param portHeight input for new screen portHeight resolutions
 */
export const pxToVh = (px, portHeight = 940) => `${(px * 100) / portHeight}vh`;

/**
 * @param px input px as per 1920 * 940 resolution if portWidth not provided, Else input as per provided resoln.
   @param portWidth input for new screen portWidth resolutions
 */
export const pxToVw = (px, portWidth = 1920) => `${(px * 100) / portWidth}vw`;
