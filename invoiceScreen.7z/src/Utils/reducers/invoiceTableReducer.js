import { createReducer } from '@reduxjs/toolkit';

const initialState = {
  status: '',
  data: [],
  pageSize: 10,
  pageNumber: 1,
  isAllChecked: false,
};

export default createReducer(initialState, {
  INVOICE_FETCH_INITIATED: (state) => ({
    ...state,
    status: 'loading',
  }),
  INVOICE_FETCH_SUCCESS: (state, action) => {
    console.log('check state in reducer', state, action);
    return {
      ...state,
      data: [...state.data, ...action.payload], //Appending the data
    };
  },
  INVOICE_FETCH_FAILED: (state) => ({ ...state, ...initialState }),
  INCREMENT_PAGE_NUMBER: (state) => ({
    ...state,
    pageNumber: state.pageNumber + 1, //Increasing page number on api call
  }),

  CHANGE_ALL_CHECKED: (state, action) => ({
    ...state,
    isAllChecked: action.data,
  }),

  CHANGE_EACH_CHECKED: (state, action) => ({
    ...state,
    data: action.data,
  }),
});
