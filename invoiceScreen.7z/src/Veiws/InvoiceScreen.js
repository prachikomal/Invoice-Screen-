import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import InvoiceTableComponent from '../Components/InvoiceTableComponent';
import { startInvoiceFetching } from '../Utils/actions/invoiceSagaActions';

function InvoiceScreen() {
  React.useEffect(() => {
    console.log('check -> in useEffect');
    startInvoiceFetching();
  });
  const data = useSelector((state) => state.invoiceTableReducer.data);
  const dispatch = useDispatch();
  const startApiCall = () => dispatch(startInvoiceFetching());

  return (
    <>
      <InvoiceTableComponent data={data} startApiCall={startApiCall} />
    </>
  );
}

export default InvoiceScreen;
